import type { NextConfig } from "next";
const staticExport = process.env.STILL_OPEN_STATIC === "1";
const config: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  output: staticExport ? "export" : undefined,
  trailingSlash: staticExport,
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || "",
};
export default config;
