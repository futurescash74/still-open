import { writeFileSync } from "node:fs";
import { fixtures } from "../src/lib/fixtures";
const docs = fixtures.map(({ _rev, ...doc }) => ({
  ...doc,
  evidence: doc.evidence.map((e) => ({ _type: "evidence", ...e })),
}));
writeFileSync(
  "sanity-seed.ndjson",
  docs.map((d) => JSON.stringify(d)).join("\n") + "\n",
);
console.log("Exported six synthetic documents. No network request was made.");
