"use client";
import { defineConfig } from "sanity";
import { structureTool } from "sanity/structure";
import { schemaTypes } from "./src/sanity/schema";
import { ReviewDesk } from "./src/sanity/ReviewDesk";
export default defineConfig({
  name: "still-open",
  title: "Still Open — synthetic demo",
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || "unconfigured",
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || "production",
  basePath: "/studio",
  schema: { types: schemaTypes },
  tools: [{ name: "review-desk", title: "Review desk", component: ReviewDesk }],
  plugins: [structureTool({ title: "Source documents" })],
});
