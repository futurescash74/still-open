import {
  claims,
  type Claim,
  type Evidence,
  type Evaluation,
  type Opportunity,
  type Proposal,
  type Reason,
} from "./model";

const DAY = 86_400_000;
export const FRESHNESS_DAYS = 14;
const currencies = new Set([
  "USD",
  "EUR",
  "GBP",
  "SEK",
  "NOK",
  "DKK",
  "CAD",
  "AUD",
  "NZD",
  "CHF",
  "JPY",
  "INR",
  "BRL",
  "SGD",
]);
const rank = (e: Evidence) => (e.sourceType === "thirdParty" ? 0 : 1);
const signature = (e: Evidence) => JSON.stringify([e.value, e.amount ?? null]);

export function evaluate(opportunity: Opportunity, now: Date): Evaluation {
  if (!Number.isFinite(now.getTime()))
    throw new Error("Evaluation time must be valid.");
  const reasons: Reason[] = [];
  const selected: Partial<Record<Claim, Evidence>> = {};
  const times: number[] = [];
  const add = (code: string, claim: Claim, label: string, detail: string) =>
    reasons.push({ code, claim, label, detail });
  for (const claim of claims) {
    const matching = (opportunity.evidence ?? []).filter(
      (e) => e.claim === claim,
    );
    const usable = matching.filter((e) => {
      const published = Date.parse(e.publishedAt),
        captured = Date.parse(e.capturedAt);
      return (
        Number.isFinite(published) &&
        Number.isFinite(captured) &&
        published <= captured &&
        captured <= now.getTime()
      );
    });
    if (matching.length !== usable.length)
      add(
        "invalid-date:" + claim,
        claim,
        "Invalid evidence date",
        "A source is future-dated, undated, or was captured before it was published.",
      );
    usable.sort(
      (a, b) =>
        rank(b) - rank(a) ||
        Date.parse(b.publishedAt) - Date.parse(a.publishedAt) ||
        a._key.localeCompare(b._key),
    );
    const latest = usable[0];
    if (!latest) {
      add(
        "missing:" + claim,
        claim,
        "Missing confirmation",
        "No usable source supports this fact.",
      );
      continue;
    }
    const tied = usable.filter(
      (e) =>
        rank(e) === rank(latest) &&
        Date.parse(e.publishedAt) === Date.parse(latest.publishedAt),
    );
    if (new Set(tied.map(signature)).size > 1) {
      add(
        "conflict:" + claim,
        claim,
        "Conflicting sources",
        "Equally authoritative sources from the same time disagree. A person must resolve this.",
      );
      continue;
    }
    selected[claim] = latest;
    const expires = Date.parse(latest.publishedAt) + FRESHNESS_DAYS * DAY;
    times.push(expires);
    if (rank(latest) === 0)
      add(
        "secondary:" + claim,
        claim,
        "Primary source needed",
        "A search result or third-party listing does not confirm the buyer’s current position.",
      );
    if (expires <= now.getTime())
      add(
        "stale:" + claim,
        claim,
        "Confirmation has expired",
        "The source is over 14 days old. A fresh capture does not make an old statement new.",
      );
  }
  const fact = (claim: Claim) => selected[claim]?.value;
  if (fact("availability") !== "open")
    add(
      "not-open",
      "availability",
      fact("availability") === "closed"
        ? "Buyer has closed this role"
        : "Availability is unconfirmed",
      "Check the buyer’s current statement before investing more time.",
    );
  if (!(
    selected.budget?.value === "amount" &&
    selected.budget?.amount &&
    Number.isFinite(selected.budget.amount) &&
    selected.budget.amount > 0
  ))
    add(
      "budget-unknown",
      "budget",
      "Budget is unconfirmed",
      "A positive numeric amount is required; a headline is not a paid assignment.",
    );
  if (!currencies.has(fact("currency") ?? ""))
    add(
      "currency-unknown",
      "currency",
      "Currency is missing or unsupported",
      "10,000 is not automatically 10,000 US dollars. Ask which currency applies.",
    );
  if (fact("reward") !== "cash")
    add(
      "not-cash",
      "reward",
      "Cash compensation is unconfirmed",
      "Product credits and simulated balances are not cash income.",
    );
  if (fact("buyer") !== "verified")
    add(
      "buyer-unverified",
      "buyer",
      "Buyer identity needs checking",
      "Confirm that the requester represents the organization.",
    );
  if (fact("payment") !== "confirmed")
    add(
      "payment-unconfirmed",
      "payment",
      "Payment route needs confirmation",
      "The buyer must confirm an available payment route for this participant.",
    );
  if (fact("scope") !== "defined")
    add(
      "scope-undefined",
      "scope",
      "Deliverables are not defined",
      "Agree on a concrete first scope before starting client work.",
    );
  if (fact("ai") !== "allowed")
    add(
      "ai-unconfirmed",
      "ai",
      "AI working method needs confirmation",
      "Ask whether an openly AI-assisted workflow is acceptable.",
    );
  const closed =
    fact("availability") === "closed" &&
    selected.availability?.sourceType !== "thirdParty";
  const state = closed ? "closed" : reasons.length ? "review" : "ready";
  const action =
    state === "closed" ? "archive" : state === "ready" ? "prepare" : "clarify";
  const amount = selected.budget?.amount;
  const currency = fact("currency");
  const budget =
    fact("reward") === "credits" && amount && Number.isFinite(amount)
      ? `${amount.toLocaleString("en-US")} credits · no cash`
      : amount && Number.isFinite(amount)
        ? `${amount.toLocaleString("en-US")}${currency && currencies.has(currency) ? " " + currency : " · currency unknown"}`
        : "Not confirmed";
  // Proposals expire in at most 24 hours; a ready proposal expires when its earliest evidence does.
  const validUntil =
    state === "ready"
      ? Math.min(now.getTime() + DAY, ...times)
      : now.getTime() + DAY;
  return {
    state,
    action,
    reasons,
    selected,
    budget,
    evaluatedAt: now.toISOString(),
    validUntil: new Date(validUntil).toISOString(),
    title:
      state === "closed"
        ? "The source says closed."
        : state === "ready"
          ? "Enough evidence to take the next step."
          : "A promising lead. A few missing facts.",
  };
}

export function propose(
  opportunity: Opportunity,
  now: Date,
  id: string,
): Proposal {
  const review = evaluate(opportunity, now);
  return {
    _id: id,
    _type: "reviewProposal",
    opportunity: { _type: "reference", _ref: opportunity._id },
    basedOnRevision: opportunity._rev,
    action: review.action,
    reasonCodes: review.reasons.map((r) => r.code).sort(),
    reasons: review.reasons.map((r) => ({ ...r })),
    budgetSnapshot: review.budget,
    proposedAt: now.toISOString(),
    validUntil: review.validUntil,
    status: "pending",
  };
}

export function approvalError(
  opportunity: Opportunity,
  proposal: Proposal,
  now: Date,
): string | undefined {
  if (proposal.opportunity._ref !== opportunity._id)
    return "This proposal belongs to another opportunity.";
  if (proposal.status !== "pending")
    return "This proposal has already been reviewed.";
  if (proposal.basedOnRevision !== opportunity._rev)
    return "The evidence changed. Generate a fresh proposal before approving.";
  if (
    !Number.isFinite(Date.parse(proposal.proposedAt)) ||
    Date.parse(proposal.proposedAt) > now.getTime() ||
    !Number.isFinite(Date.parse(proposal.validUntil)) ||
    Date.parse(proposal.validUntil) <= now.getTime()
  )
    return "This proposal has expired or has an invalid date. Generate a fresh one.";
  const current = evaluate(opportunity, now);
  if (
    current.action !== proposal.action ||
    JSON.stringify(current.reasons.map((r) => r.code).sort()) !==
      JSON.stringify([...proposal.reasonCodes].sort())
  )
    return "The assessment changed. Generate a fresh proposal before approving.";
  return undefined;
}
