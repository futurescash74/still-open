export const claims = [
  "availability",
  "budget",
  "currency",
  "reward",
  "buyer",
  "payment",
  "scope",
  "ai",
] as const;
export type Claim = (typeof claims)[number];
export type Evidence = {
  _key: string;
  claim: Claim;
  value: string;
  amount?: number;
  sourceType: "buyer" | "official" | "thirdParty";
  sourceLabel: string;
  sourceUrl: string;
  excerpt: string;
  publishedAt: string;
  capturedAt: string;
};
export type Opportunity = {
  _id: string;
  _type: "opportunity";
  _rev: string;
  title: string;
  buyer: string;
  category: string;
  summary: string;
  effort: string;
  synthetic: true;
  evidence: Evidence[];
};
export type Action = "clarify" | "prepare" | "archive";
export type Reason = {
  code: string;
  label: string;
  detail: string;
  claim: Claim;
};
export type Evaluation = {
  state: "review" | "ready" | "closed";
  action: Action;
  title: string;
  reasons: Reason[];
  selected: Partial<Record<Claim, Evidence>>;
  evaluatedAt: string;
  validUntil: string;
  budget: string;
};
export type Proposal = {
  _id: string;
  _type: "reviewProposal";
  opportunity: { _type: "reference"; _ref: string };
  basedOnRevision: string;
  action: Action;
  reasonCodes: string[];
  reasons: Reason[];
  budgetSnapshot: string;
  proposedAt: string;
  validUntil: string;
  status: "pending" | "approved" | "rejected";
  reviewedAt?: string;
  reviewerId?: string;
};
export const claimLabels: Record<Claim, string> = {
  availability: "Still available",
  budget: "Budget",
  currency: "Currency",
  reward: "Cash or credits",
  buyer: "Buyer identity",
  payment: "Payment route",
  scope: "Defined scope",
  ai: "AI working method",
};
export const actionLabels: Record<Action, string> = {
  clarify: "Ask for clarification",
  prepare: "Prepare a proposal",
  archive: "Archive opportunity",
};
export function safeSourceUrl(value: string) {
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) &&
      !url.username &&
      !url.password
      ? url.href
      : undefined;
  } catch {
    return undefined;
  }
}
