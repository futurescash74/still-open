import { type Claim, type Evidence, type Opportunity } from "./model";

export const DEMO_NOW = "2026-09-27T12:00:00.000Z";
const fresh = "2026-09-26T10:00:00.000Z";
function evidence(
  claim: Claim,
  value: string,
  excerpt: string,
  extras: Partial<Evidence> = {},
): Evidence {
  return {
    _key: `${claim}-initial`,
    claim,
    value,
    sourceType: "buyer",
    sourceLabel: "Fictional buyer brief",
    sourceUrl: "https://example.com/fictional-brief",
    excerpt,
    publishedAt: fresh,
    capturedAt: DEMO_NOW,
    ...extras,
  };
}
function complete(
  scope = "Deliver a webhook receiver, duplicate protection, error logs, and a handover guide using synthetic input.",
): Evidence[] {
  return [
    evidence(
      "availability",
      "open",
      "We are still accepting proposals for this project.",
    ),
    evidence(
      "budget",
      "amount",
      "The budget for the initial milestone is 1,200 USD.",
      { amount: 1200 },
    ),
    evidence("currency", "USD", "All amounts are in US dollars."),
    evidence(
      "reward",
      "cash",
      "Payment is cash compensation, not platform credits.",
    ),
    evidence(
      "buyer",
      "verified",
      "The brief was confirmed through the organization’s published contact address.",
    ),
    evidence(
      "payment",
      "confirmed",
      "We can pay a Swedish individual through PayPal Goods and Services.",
    ),
    evidence(
      "scope",
      "defined",
      scope,
    ),
    evidence(
      "ai",
      "allowed",
      "AI-assisted implementation is welcome when disclosed and tested.",
    ),
  ];
}
const base = (
  id: string,
  title: string,
  buyer: string,
  category: string,
  summary: string,
  effort: string,
  e: Evidence[],
): Opportunity => ({
  _id: `demo-${id}`,
  _type: "opportunity",
  _rev: `seed-${id}-1`,
  title,
  buyer,
  category,
  summary,
  effort,
  synthetic: true,
  evidence: e,
});
export const fixtures: Opportunity[] = [
  base(
    "currency",
    "A redesign with a missing currency",
    "Northstar Objects",
    "Web development",
    "A promising website brief says “10,000+”. The budget looks large until you ask what the number actually means.",
    "3–5 days",
    complete("Redesign a responsive three-page product website and quote-request flow, with a handover guide.").map((e) =>
      e.claim === "budget"
        ? {
            ...e,
            amount: 10000,
            excerpt: "Budget: 10,000+. Please send your proposal.",
          }
        : e.claim === "currency"
          ? {
              ...e,
              value: "unknown",
              excerpt: "The listing does not name a currency.",
            }
          : e,
    ),
  ),
  base(
    "ready",
    "One webhook. No duplicate orders.",
    "Juniper Workshop",
    "Automation",
    "A bounded integration brief with a named buyer, a defined first milestone and a confirmed payment route.",
    "1–2 days",
    complete(),
  ),
  base(
    "closed",
    "The listing that stayed open",
    "Orbit Library",
    "Documentation",
    "A search result still invites applications. The buyer’s newer post says the project has already been assigned.",
    "Half a day",
    [
      ...complete("Update one getting-started guide and check its two code examples against the documented SDK."),
      evidence(
        "availability",
        "closed",
        "Update: this project has been filled. Thank you to everyone who applied.",
        {
          _key: "availability-closure",
          publishedAt: "2026-09-27T08:00:00.000Z",
          sourceLabel: "Fictional buyer update",
        },
      ),
      evidence("availability", "open", "Open documentation role. Apply now.", {
        _key: "availability-cache",
        sourceType: "thirdParty",
        sourceLabel: "Fictional cached listing",
        publishedAt: "2026-09-27T09:00:00.000Z",
      }),
    ],
  ),
  base(
    "credits",
    "A reward that is not a payment",
    "Cloudberry Tools",
    "Product testing",
    "The headline offers a 500 reward. The detailed terms specify account credits with no cash withdrawal.",
    "2 hours",
    complete("Test signup, filtering, and export with synthetic sample records, then submit a short issue report.").map((e) =>
      e.claim === "reward"
        ? {
            ...e,
            value: "credits",
            excerpt:
              "Successful testers receive 500 account credits. Credits have no cash value.",
          }
        : e.claim === "budget"
          ? { ...e, amount: 500, excerpt: "Reward for accepted testing reports: 500 account credits." }
          : e.claim === "currency"
            ? { ...e, value: "not_applicable", excerpt: "The reward is denominated in product credits, not a cash currency." }
            : e.claim === "payment"
              ? { ...e, value: "unknown", excerpt: "Credits stay in your product account and cannot be withdrawn through PayPal or a bank." }
              : e,
    ),
  ),
  base(
    "stale",
    "Fresh search, old invitation",
    "Morrow Fieldnotes",
    "Technical writing",
    "The page was captured today. The actual invitation is from three months ago, with no new buyer confirmation.",
    "1 day",
    complete("Write a tested technical tutorial, include the sample project, and revise it once after editorial review.").map((e) => ({ ...e, publishedAt: "2026-06-01T10:00:00.000Z" })),
  ),
  base(
    "payment",
    "Good scope, unclear payout",
    "Tiny Observatory",
    "Data cleanup",
    "The dataset and acceptance criteria are clear. Eligibility for the promised payment route is still unanswered.",
    "4–6 hours",
    complete("Normalize the supplied synthetic CSV, document duplicate rules, and deliver a cleaned file with a row-count reconciliation.").map((e) =>
      e.claim === "payment"
        ? {
            ...e,
            value: "unknown",
            excerpt:
              "We will discuss payment details after accepting the work.",
          }
        : e,
    ),
  ),
];
export function currencyUpdate(now: string): Evidence {
  return evidence(
    "currency",
    "SEK",
    "Clarification: the 10,000 budget is in Swedish kronor (SEK).",
    {
      _key: "currency-followup-" + Date.parse(now),
      sourceLabel: "Fictional buyer clarification",
      publishedAt: now,
      capturedAt: now,
    },
  );
}
