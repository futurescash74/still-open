import { createClient } from "@sanity/client";
import type { Opportunity } from "./model";
export const projectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || "";
export const dataset = process.env.NEXT_PUBLIC_SANITY_DATASET || "production";
export const apiVersion = "2026-09-01";
export const query =
  '*[_type == "opportunity" && synthetic == true && !(_id in path("drafts.**")) && !(_id in path("versions.**"))] | order(_id asc) {_id,_type,_rev,title,buyer,category,summary,effort,synthetic,evidence}';
export function readClient() {
  return createClient({
    projectId,
    dataset,
    apiVersion,
    useCdn: false,
    withCredentials: false,
    perspective: "published",
  });
}
export async function loadOpportunities(): Promise<Opportunity[]> {
  return readClient().fetch(query, {}, { cache: "no-store" });
}
