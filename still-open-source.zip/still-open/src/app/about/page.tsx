import { appPath } from "@/lib/paths";
export default function About() {
  return (
    <main className="about">
      <a href={appPath("/")}>← Back to the desk</a>
      <h1>
        A promising lead is
        <br />
        not a paid job.
      </h1>
      <p>
        Still Open is an evidence-first opportunity desk built with Next.js and
        Sanity. It turns uncertain listings into explicit observations and
        proposed next steps. Every example is fictional.
      </p>
      <h2>Why this exists</h2>
      <p>
        A fresh search result can point to an old listing. A large number can
        have no currency. A “reward” can mean account credits. This app makes
        those gaps visible before anyone invests hours of delivery work.
      </p>
      <h2>Three different things, three different records</h2>
      <ul>
        <li>
          <strong>An opportunity</strong> describes a possible project.
        </li>
        <li>
          <strong>Source observations</strong> preserve what was stated, where,
          and when it was published and captured. They are structured objects
          within the opportunity.
        </li>
        <li>
          <strong>A review proposal</strong> references the opportunity and the
          exact revision used to assess it. A later human review does not
          overwrite the source.
        </li>
      </ul>
      <h2>Rules before confidence scores</h2>
      <p>
        Eight explicit checks cover availability, budget, currency, compensation
        type, buyer identity, payment route, scope, and AI acceptance. Direct
        buyer and official sources outrank secondary listings. Conflicting
        equal-time sources stay unresolved. Evidence older than 14 days must be
        reconfirmed. The evaluator uses a documented currency allowlist;
        unsupported currencies require review instead of being guessed.
      </p>
      <h2>What Sanity does</h2>
      <p>
        When configured, the main board reads published synthetic opportunities
        from Sanity’s Content Lake. The authenticated Studio workspace creates
        separate proposals and records review decisions. Approval uses a
        transaction with revision checks on both the opportunity and proposal,
        so a change between reading and writing is rejected.
      </p>
      <h2>What the public demo does</h2>
      <p>
        The public board lets you rehearse proposals and simulate a buyer
        clarification in your browser tab. Those interactions are deliberately
        local. Refreshing restores the source dataset. The local demo uses a
        fixed clock of 27 September 2026 at 12:00 UTC so its scenarios remain
        reproducible. The Sanity-connected board uses the time it was loaded;
        the authenticated editor uses the current time. The separate{" "}
        <a href={appPath("/demo")}>/demo route</a> always uses local fixtures.
      </p>
      <h2>Limits we keep visible</h2>
      <ul>
        <li>
          No messages are sent, contracts accepted, or payments processed.
        </li>
        <li>
          Source facts are manually entered. “Verified” means an editor recorded
          a verification, not that the app independently verified a person.
        </li>
        <li>
          The review suggestion is deterministic. There is no runtime LLM and no
          AI API bill.
        </li>
        <li>
          Application checks are not a security boundary against project
          administrators. Sanity administrators can edit data outside this
          workflow.
        </li>
        <li>
          Observations are append-only through the custom workflow, but are not
          a cryptographically immutable audit log.
        </li>
        <li>
          The six sample opportunities do not include receipts. The demo records
          zero payments and never adds advertised budgets to income.
        </li>
        <li>
          Shared data is refreshed manually. No claim of realtime cross-client
          synchronization is made.
        </li>
      </ul>
      <h2>Built with AI, described honestly</h2>
      <p>
        The implementation, synthetic scenarios, and this write-up were produced
        with an AI coding agent. The project is intended as a transparent
        working example, not a claim of prior client engagements.
      </p>
      <p>
        <a href="https://www.sanity.io/docs/content-lake/transactions">
          Sanity transactions
        </a>{" "}
        ·{" "}
        <a href="https://www.sanity.io/docs/studio/embedding-sanity-studio">
          Embedded Studio
        </a>{" "}
        ·{" "}
        <a href="https://dev.to/challenges/sanity-2026-09-16">
          Sanity DEV Challenge
        </a>
      </p>
    </main>
  );
}
