import { appPath } from "@/lib/paths";
import Board from "@/components/Board";
import { fixtures, DEMO_NOW } from "@/lib/fixtures";
import { loadOpportunities, projectId } from "@/lib/sanity";
import LiveBoard from "@/components/LiveBoard";
export default async function Page() {
  if (process.env.STILL_OPEN_STATIC === "1") return <LiveBoard />;
  if (!projectId)
    return <Board initial={fixtures} asOf={DEMO_NOW} source="fixture" />;
  try {
    const items = await loadOpportunities();
    if (!items.length)
      return (
        <Board
          initial={[]}
          asOf={new Date().toISOString()}
          source="sanity"
          projectId={projectId}
          notice="Sanity is connected, but the synthetic dataset is empty. An editor can load the six sample cases in the editor workspace."
        />
      );
    return (
      <Board
        initial={items.sort((a, b) =>
          a._id === "demo-currency"
            ? -1
            : b._id === "demo-currency"
              ? 1
              : a.title.localeCompare(b.title),
        )}
        asOf={new Date().toISOString()}
        source="sanity"
        projectId={projectId}
      />
    );
  } catch {
    return (
      <main className="connection-error">
        <h1>The source is unavailable.</h1>
        <p>
          We could not read the configured Sanity dataset. Sample data has not
          silently replaced it.
        </p>
        <a href={appPath("/demo")}>Open the separate local demo</a>
        <a href={appPath("/studio")}>Check the editor workspace</a>
      </main>
    );
  }
}
