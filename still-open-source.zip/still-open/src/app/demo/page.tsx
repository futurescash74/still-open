import Board from "@/components/Board";
import { fixtures, DEMO_NOW } from "@/lib/fixtures";
export default function Demo() {
  return (
    <Board
      initial={fixtures}
      asOf={DEMO_NOW}
      source="fixture"
      notice="This route always uses local sample data. It is independent of the shared Sanity dataset."
    />
  );
}
