import { NextStudio } from "next-sanity/studio";
import config from "../../../../sanity.config";
export { metadata, viewport } from "next-sanity/studio";
export function generateStaticParams() {
  return [{ tool: [] }];
}
export default function StudioPage() {
  if (process.env.STILL_OPEN_STATIC === "1")
    return (
      <main className="studio-unconfigured">
        <h1>The editor runs locally</h1>
        <p>
          This public export provides a read-only Sanity connection and a local
          interactive rehearsal. Run the repository with your own Sanity project
          to use authenticated shared reviews.
        </p>
        <a href={`${process.env.NEXT_PUBLIC_BASE_PATH || ""}/about/`}>
          Read the build notes →
        </a>
      </main>
    );
  if (!process.env.NEXT_PUBLIC_SANITY_PROJECT_ID)
    return (
      <main className="studio-unconfigured">
        <h1>Connect a Sanity project</h1>
        <p>
          Add the project ID and dataset from your own Sanity project to the
          local environment configuration. Do not put a write token in the
          public app.
        </p>
        <a href="/demo">Explore the local demo →</a>
      </main>
    );
  return (
    <div className="studio-shell">
      <NextStudio config={config} />
    </div>
  );
}
