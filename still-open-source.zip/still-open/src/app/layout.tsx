import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Still Open — Evidence before effort",
  description:
    "An evidence-first opportunity desk. A synthetic Next.js and Sanity workflow demonstration.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
