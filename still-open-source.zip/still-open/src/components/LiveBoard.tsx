"use client";
import { useEffect, useState } from "react";
import Board from "./Board";
import { projectId, loadOpportunities } from "../lib/sanity";
import { DEMO_NOW, fixtures } from "../lib/fixtures";
import { appPath } from "../lib/paths";
import type { Opportunity } from "../lib/model";
export default function LiveBoard() {
  const [data, setData] = useState<{
    items: Opportunity[];
    asOf: string;
  } | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (!projectId) return;
    let active = true;
    loadOpportunities()
      .then((items) => {
        if (active)
          setData({
            items: items.sort((a, b) =>
              a._id === "demo-currency"
                ? -1
                : b._id === "demo-currency"
                  ? 1
                  : a.title.localeCompare(b.title),
            ),
            asOf: new Date().toISOString(),
          });
      })
      .catch(() => {
        if (active) setFailed(true);
      });
    return () => {
      active = false;
    };
  }, []);
  if (!projectId)
    return <Board initial={fixtures} asOf={DEMO_NOW} source="fixture" />;
  if (failed)
    return (
      <main className="connection-error">
        <h1>The source is unavailable.</h1>
        <p>
          The shared Sanity data could not be loaded. No sample data has been
          substituted.
        </p>
        <a href={appPath("/demo/")}>Open the separate local demo</a>
      </main>
    );
  if (!data)
    return (
      <main className="connection-error" aria-live="polite">
        <h1>Opening the evidence desk…</h1>
        <p>Reading the synthetic dataset from Sanity.</p>
      </main>
    );
  return (
    <Board
      initial={data.items}
      asOf={data.asOf}
      source="sanity"
      projectId={projectId}
      notice={
        data.items.length
          ? undefined
          : "Sanity is connected, but no synthetic records have been published yet."
      }
    />
  );
}
