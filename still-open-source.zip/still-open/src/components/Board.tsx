"use client";
import { appPath } from "@/lib/paths";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  ArrowRight,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  FileCheck2,
  Layers3,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { approvalError, evaluate, propose } from "@/lib/evaluate";
import { currencyUpdate } from "@/lib/fixtures";
import {
  actionLabels,
  claimLabels,
  claims,
  safeSourceUrl,
  type Opportunity,
  type Proposal,
} from "@/lib/model";

type Props = {
  initial: Opportunity[];
  asOf: string;
  source: "fixture" | "sanity";
  projectId?: string;
  notice?: string;
};
const stateLabel = {
  review: "Needs a closer look",
  ready: "Ready for a proposal",
  closed: "Closed by the buyer",
};
const shortDate = (date: string) =>
  new Date(date).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    timeZone: "UTC",
  });

export default function Board({
  initial,
  asOf,
  source,
  projectId,
  notice,
}: Props) {
  const [items, setItems] = useState(initial);
  const [selectedId, setSelectedId] = useState(initial[0]?._id);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<"evidence" | "review">("evidence");
  const [proposals, setProposals] = useState<Record<string, Proposal>>({});
  const [feedback, setFeedback] = useState("");
  const [guide, setGuide] = useState(false);
  const [simulated, setSimulated] = useState(false);
  const [daysAhead, setDaysAhead] = useState(0);
  const guideRef = useRef<HTMLElement>(null);
  const detailRef = useRef<HTMLElement>(null);
  const evidenceTabRef = useRef<HTMLButtonElement>(null);
  const reviewTabRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!guide) return;
    const before = document.activeElement as HTMLElement | null;
    const modal = guideRef.current;
    const focusable = () =>
      Array.from(
        modal?.querySelectorAll<HTMLElement>(
          'button,a[href],input,[tabindex="0"]',
        ) ?? [],
      );
    focusable()[0]?.focus();
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setGuide(false);
      }
      if (event.key === "Tab") {
        const nodes = focusable(),
          first = nodes[0],
          last = nodes[nodes.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", keydown);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", keydown);
      before?.focus();
    };
  }, [guide]);
  const now = useMemo(
    () => new Date(Date.parse(asOf) + daysAhead * 86_400_000),
    [asOf, daysAhead],
  );
  const all = items.map((item) => ({ item, review: evaluate(item, now) }));
  const visible = all.filter(
    ({ item, review }) =>
      (filter === "all" || review.state === filter) &&
      [item.title, item.buyer, item.category]
        .join(" ")
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  const selected =
    visible.find(({ item }) => item._id === selectedId)?.item ??
    visible[0]?.item;
  const review = selected ? evaluate(selected, now) : undefined;
  const proposal = selected ? proposals[selected._id] : undefined;
  const error =
    selected && proposal ? approvalError(selected, proposal, now) : undefined;
  const counts = {
    review: all.filter((x) => x.review.state === "review").length,
    ready: all.filter((x) => x.review.state === "ready").length,
    closed: all.filter((x) => x.review.state === "closed").length,
  };
  function select(id: string) {
    setSelectedId(id);
    setTab("evidence");
    setFeedback("");
    if (window.matchMedia("(max-width:640px)").matches)
      requestAnimationFrame(() =>
        detailRef.current?.scrollIntoView({
          behavior: window.matchMedia("(prefers-reduced-motion:reduce)").matches
            ? "auto"
            : "smooth",
          block: "start",
        }),
      );
  }
  function generate() {
    if (!selected) return;
    const p = propose(selected, now, crypto.randomUUID());
    setProposals({ ...proposals, [selected._id]: p });
    setFeedback("A proposed next step is ready for your review.");
    setTab("review");
    setSimulated(true);
  }
  function approve() {
    if (!selected || !proposal) return;
    const blocked = approvalError(selected, proposal, now);
    if (blocked) {
      setFeedback(blocked);
      return;
    }
    setProposals({
      ...proposals,
      [selected._id]: {
        ...proposal,
        status: "approved",
        reviewedAt: now.toISOString(),
        reviewerId: "demo-reviewer",
      },
    });
    setFeedback(
      "Review recorded in this browser session. No message was sent and no agreement was made.",
    );
    setSimulated(true);
  }
  function addClarification() {
    if (!selected) return;
    setItems(
      items.map((item) =>
        item._id === selected._id
          ? {
              ...item,
              _rev: item._rev + "-clarified",
              evidence: [...item.evidence, currencyUpdate(now.toISOString())],
            }
          : item,
      ),
    );
    setFeedback(
      "A newer source confirms SEK. Existing proposals now need a fresh review.",
    );
    setSimulated(true);
  }
  function reset() {
    setItems(initial);
    setSelectedId(initial[0]?._id);
    setFilter("all");
    setQuery("");
    setTab("evidence");
    setProposals({});
    setDaysAhead(0);
    setSimulated(false);
    setFeedback("Demo changes cleared. The original data is restored.");
  }
  return (
    <div className="app-shell">
      <aside className="rail">
        <a className="brand" href={appPath("/")} aria-label="Still Open home">
          <span className="brand-mark">
            <Layers3 size={22} />
          </span>
          <span>
            still open<span className="brand-period">.</span>
          </span>
        </a>
        <div className="workspace">
          <div className="workspace-avatar">SO</div>
          <div>
            Opportunity desk<small>Synthetic demonstration</small>
          </div>
        </div>
        <span className="eyebrow rail-label">WORKSPACE</span>
        <nav aria-label="Workspace">
          <button
            className="nav-active"
            onClick={() => {
              setFilter("all");
              setQuery("");
            }}
          >
            <Layers3 size={18} /> Opportunity board <span>{items.length}</span>
          </button>
          <button onClick={() => setGuide(true)}>
            <CircleHelp size={18} /> How this works <ArrowUpRight size={15} />
          </button>
          <a href={appPath("/studio")}>
            <ShieldCheck size={18} /> Editor workspace{" "}
            <ArrowUpRight size={15} />
          </a>
        </nav>
        <div className="rail-note">
          <div className="little-flower">✳</div>
          <p>
            A good lead starts
            <br />
            with a better question.
          </p>
          <span>Evidence before effort.</span>
        </div>
        <footer className="rail-footer">
          <span className="status-dot" />{" "}
          {source === "sanity" ? "Connected to Sanity" : "Local sample data"}
          <small>
            {projectId
              ? `Project ${projectId}`
              : "No shared writes from this tab"}
          </small>
        </footer>
      </aside>
      <main className="main">
        <header className="topbar">
          <span>
            Workspace <ChevronRight size={13} /> Opportunities
          </span>
          <span className="date-stamp">
            <Clock3 size={14} />
            {shortDate(now.toISOString())} {now.getUTCFullYear()} ·{" "}
            {daysAhead
              ? "simulated future"
              : source === "sanity"
                ? "source snapshot"
                : "demo clock"}
          </span>
        </header>
        <section className="heading-row">
          <div>
            <span className="eyebrow">THE OPPORTUNITY DESK</span>
            <h1>Worth your next hour?</h1>
            <p>Check the evidence. Decide what deserves your time.</p>
          </div>
          <button className="quiet-button" onClick={reset}>
            <RefreshCw size={15} /> Reset demo
          </button>
        </section>
        {notice && (
          <div className="notice" role="status">
            {notice}
          </div>
        )}
        <div className="demo-strip">
          <span className="demo-tag">INTERACTIVE DEMO</span>
          <span>
            Fictional opportunities.{" "}
            {source === "sanity" ? "Loaded from Sanity." : "Local sample data."}{" "}
            Changes stay in this tab.
          </span>
          {simulated && <strong>Local changes</strong>}
        </div>
        <div className="time-machine">
          <span>
            <Clock3 size={14} />
            <strong>Try the expiry test</strong> Would you still trust this
            brief in two weeks?
          </span>
          <button
            onClick={() => {
              setDaysAhead(daysAhead ? 0 : 14);
              setFeedback(
                daysAhead
                  ? "Returned to the original evidence clock."
                  : "Two weeks later: confirmations expire even when the documents have not changed.",
              );
            }}
          >
            {daysAhead ? "Return to today" : "Fast-forward 14 days"}{" "}
            <ArrowRight size={13} />
          </button>
        </div>
        <section className="metrics" aria-label="Board overview">
          <div>
            <span>To investigate</span>
            <strong>{String(counts.review).padStart(2, "0")}</strong>
            <small>Questions still open</small>
          </div>
          <div>
            <span>Ready for a proposal</span>
            <strong className="green">
              {String(counts.ready).padStart(2, "0")}
            </strong>
            <small>Evidence checks passed</small>
          </div>
          <div>
            <span>Closed opportunities</span>
            <strong>{String(counts.closed).padStart(2, "0")}</strong>
            <small>Time you can reclaim</small>
          </div>
          <div className="earnings">
            <span>Payments recorded</span>
            <strong>0</strong>
            <small>Advertised budgets are not income</small>
          </div>
        </section>
        <div className="board-toolbar">
          <div
            className="filters"
            role="group"
            aria-label="Filter opportunities"
          >
            {[
              ["all", "All opportunities"],
              ["review", "Needs review"],
              ["ready", "Ready"],
              ["closed", "Closed"],
            ].map(([value, label]) => (
              <button
                key={value}
                aria-pressed={filter === value}
                className={filter === value ? "active" : ""}
                onClick={() => {
                  setFilter(value);
                  setTab("evidence");
                  setFeedback("");
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <label className="search">
            <Search size={16} />
            <input
              aria-label="Search opportunities"
              placeholder="Find an opportunity…"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setTab("evidence");
                setFeedback("");
              }}
            />
          </label>
        </div>
        <div className="board-grid">
          <section className="opportunity-list" aria-label="Opportunities">
            <div className="list-caption">
              <span>{visible.length} OPPORTUNITIES</span>
              <span>ADVERTISED BUDGET</span>
            </div>
            {visible.length === 0 ? (
              <div className="empty">
                <Search />
                <h3>No matching opportunities</h3>
                <p>Try another search or filter.</p>
                <button
                  onClick={() => {
                    setFilter("all");
                    setQuery("");
                  }}
                >
                  Clear filters
                </button>
              </div>
            ) : (
              visible.map(({ item, review: r }) => (
                <button
                  className={`opportunity-card ${selected?._id === item._id ? "selected" : ""}`}
                  key={item._id}
                  onClick={() => select(item._id)}
                  aria-pressed={selected?._id === item._id}
                >
                  <div className="card-top">
                    <span className={`pill ${r.state}`}>
                      <span />
                      {stateLabel[r.state]}
                    </span>
                    <ArrowUpRight size={16} />
                  </div>
                  <h2>{item.title}</h2>
                  <p>
                    {item.buyer} <span>·</span> {item.category}
                  </p>
                  <div className="card-bottom">
                    <span>
                      <Clock3 size={13} />
                      {item.effort}
                    </span>
                    <strong>{r.budget}</strong>
                  </div>
                  {r.state === "review" && (
                    <div className="card-reason">
                      <CircleHelp size={13} />
                      {r.reasons.find((x) => !x.code.startsWith("missing:"))
                        ?.label ?? r.reasons[0]?.label}
                    </div>
                  )}
                </button>
              ))
            )}
            <div className="list-footnote">
              A source can change. So should the decision.
            </div>
          </section>
          {selected && review ? (
            <section
              ref={detailRef}
              className="detail"
              aria-label="Selected opportunity"
            >
              <div className="detail-heading">
                <span className="eyebrow">OPPORTUNITY NOTES</span>
                <span className="fictional">FICTIONAL CASE</span>
                <h2>{selected.title}</h2>
                <p>{selected.summary}</p>
              </div>
              <div
                className="detail-tabs"
                role="tablist"
                aria-label="Opportunity details"
                onKeyDown={(event) => {
                  if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key))
                    return;
                  event.preventDefault();
                  const next = event.key === "Home"
                    ? "evidence"
                    : event.key === "End"
                      ? "review"
                      : tab === "evidence" ? "review" : "evidence";
                  setTab(next);
                  (next === "evidence" ? evidenceTabRef : reviewTabRef).current?.focus();
                }}
              >
                <button
                  ref={evidenceTabRef}
                  id="evidence-tab"
                  role="tab"
                  aria-controls="evidence-panel"
                  aria-selected={tab === "evidence"}
                  tabIndex={tab === "evidence" ? 0 : -1}
                  onClick={() => setTab("evidence")}
                >
                  The evidence <span>{selected.evidence.length}</span>
                </button>
                <button
                  ref={reviewTabRef}
                  id="review-tab"
                  role="tab"
                  aria-controls="review-panel"
                  aria-selected={tab === "review"}
                  tabIndex={tab === "review" ? 0 : -1}
                  onClick={() => setTab("review")}
                >
                  Next step {proposal && <span>1</span>}
                </button>
              </div>
              {tab === "evidence" ? (
                <div className="detail-body" role="tabpanel" id="evidence-panel" aria-labelledby="evidence-tab">
                  <div className={`assessment ${review.state}`}>
                    <span className="assessment-icon">
                      {review.state === "ready" ? (
                        <Check size={19} />
                      ) : review.state === "closed" ? (
                        <X size={19} />
                      ) : (
                        <CircleHelp size={19} />
                      )}
                    </span>
                    <div>
                      <strong>{review.title}</strong>
                      <p>
                        {review.state === "ready"
                          ? "Ready to discuss a paid scope. No contract or payment is implied."
                          : review.state === "closed"
                            ? "The direct source outweighs the cached listing."
                            : `${new Set(review.reasons.map((r) => r.claim)).size} of 8 facts need attention before starting work.`}
                      </p>
                    </div>
                  </div>
                  <div className="facts-grid">
                    {claims.map((claim) => {
                      const e = review.selected[claim];
                      const issue = review.reasons.some(
                        (r) => r.claim === claim,
                      );
                      return (
                        <div key={claim}>
                          <span>{claimLabels[claim]}</span>
                          <strong className={issue ? "amber" : ""}>
                            {issue ? (
                              <CircleHelp size={13} />
                            ) : (
                              <Check size={13} />
                            )}{" "}
                            {claim === "budget"
                              ? review.budget
                              : (e?.value?.replaceAll("_", " ") ??
                                "Not confirmed")}
                          </strong>
                        </div>
                      );
                    })}
                  </div>
                  <div className="section-label">
                    <h3>Follow the source</h3>
                    <span>{selected.evidence.length} observations</span>
                  </div>
                  <div className="evidence-timeline">
                    {[...selected.evidence]
                      .sort(
                        (a, b) =>
                          Date.parse(b.publishedAt) - Date.parse(a.publishedAt),
                      )
                      .map((e) => (
                        <article className="evidence-item" key={e._key}>
                          <span
                            className={`timeline-dot ${e.sourceType === "thirdParty" ? "secondary" : ""}`}
                          />
                          <header>
                            <strong>{claimLabels[e.claim]}</strong>
                            <time dateTime={e.publishedAt}>
                              {shortDate(e.publishedAt)}
                            </time>
                          </header>
                          <p>“{e.excerpt}”</p>
                          <div>
                            <span>
                              {e.sourceType === "thirdParty"
                                ? "Secondary source"
                                : "Direct source"}
                            </span>
                            {safeSourceUrl(e.sourceUrl) && (
                              <a
                                href={safeSourceUrl(e.sourceUrl)}
                                target="_blank"
                                rel="noreferrer"
                              >
                                {e.sourceLabel}
                                <ArrowUpRight size={12} />
                              </a>
                            )}
                          </div>
                        </article>
                      ))}
                  </div>
                </div>
              ) : (
                <div className="detail-body" role="tabpanel" id="review-panel" aria-labelledby="review-tab">
                  <div className="review-intro">
                    <FileCheck2 size={26} />
                    <h3>
                      A proposed action,
                      <br />
                      not an automatic commitment.
                    </h3>
                    <p>
                      The rules suggest a next step. A reviewer decides whether
                      to record it. Nothing is sent to the buyer.
                    </p>
                  </div>
                  {proposal ? (
                    <div className="proposal">
                      <div className="section-label">
                        <span className="eyebrow">
                          {proposal.status === "approved"
                            ? "REVIEWED IN THIS TAB"
                            : "PROPOSED NEXT STEP"}
                        </span>
                        <span
                          className={`pill ${proposal.status === "approved" ? "ready" : "review"}`}
                        >
                          {proposal.status}
                        </span>
                      </div>
                      <h3>{actionLabels[proposal.action]}</h3>
                      <p>
                        {proposal.action === "clarify"
                          ? "Ask the buyer to resolve the outstanding facts before committing delivery time."
                          : proposal.action === "archive"
                            ? "Move attention away from a role the buyer has closed."
                            : "Prepare a scoped proposal for review. This is not permission to accept a contract."}
                      </p>
                      <ul>
                        {proposal.reasons.map((reason) => (
                          <li key={reason.code}>
                            <strong>{reason.label}</strong>
                            <span>{reason.detail}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="revision-note">
                        Linked to evidence revision{" "}
                        <code>{proposal.basedOnRevision.slice(0, 24)}</code>
                      </div>
                      {error && proposal.status === "pending" && (
                        <p className="error" role="alert">
                          {error}
                        </p>
                      )}
                      <button
                        className="primary-button"
                        disabled={!!error}
                        onClick={approve}
                      >
                        <Check size={16} />
                        {proposal.status === "approved"
                          ? "Review recorded"
                          : "Record my review"}
                      </button>
                    </div>
                  ) : (
                    <div className="empty-review">
                      <p>
                        No proposal yet. Generate one from the current evidence.
                      </p>
                      <button className="primary-button" onClick={generate}>
                        <Sparkles size={16} /> Propose a next step
                      </button>
                    </div>
                  )}
                  <div className="explainer">
                    <strong>Evidence can move underneath a decision.</strong>
                    <p>
                      Change the missing currency after generating a proposal.
                      The old proposal is blocked until you assess the new
                      evidence.
                    </p>
                    {selected._id === "demo-currency" &&
                      !selected.evidence.some((e) =>
                        e._key.startsWith("currency-followup"),
                      ) && (
                        <button
                          className="text-button"
                          onClick={addClarification}
                        >
                          Simulate a buyer clarification{" "}
                          <ArrowRight size={15} />
                        </button>
                      )}
                  </div>
                </div>
              )}
              <div className="detail-footer">
                <p className="feedback" role="status" aria-live="polite">
                  {feedback ||
                    "Only authenticated editors can save shared reviews in Sanity."}
                </p>
                <button className="primary-button" onClick={generate}>
                  <Sparkles size={15} />
                  {proposal ? "Reassess evidence" : "Propose a next step"}
                  <ArrowRight size={15} />
                </button>
              </div>
            </section>
          ) : (
            <section className="detail empty">
              <p>Select an opportunity to inspect its evidence.</p>
            </section>
          )}
        </div>
        <footer className="main-footer">
          <span>
            STILL OPEN <span className="brand-period">✳</span> Evidence before
            effort.
          </span>
          <a href={appPath("/about")}>
            Build notes & limitations <ArrowUpRight size={13} />
          </a>
        </footer>
      </main>
      {guide && (
        <div className="modal-backdrop" onClick={() => setGuide(false)}>
          <section
            ref={guideRef}
            className="guide-modal"
            role="dialog"
            aria-modal="true"
            aria-label="How Still Open works"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="close-button"
              aria-label="Close guide"
              onClick={() => setGuide(false)}
            >
              <X size={20} />
            </button>
            <span className="eyebrow">A SMALLER, SMARTER PIPELINE</span>
            <h2>
              Slow down
              <br />
              the wrong work.
            </h2>
            <ol>
              <li>
                <strong>Observe</strong>
                <p>
                  Keep the source’s publication date, not just the day you found
                  it.
                </p>
              </li>
              <li>
                <strong>Qualify</strong>
                <p>
                  Check eight explicit facts. Missing information stays unknown.
                </p>
              </li>
              <li>
                <strong>Review</strong>
                <p>
                  A suggested next step needs review against the same evidence
                  revision.
                </p>
              </li>
            </ol>
            <p className="notice">
              This is a synthetic workflow demo. It does not find jobs, send
              messages, verify identities automatically, or process payments.
            </p>
            <button className="primary-button" onClick={() => setGuide(false)}>
              Explore the evidence <ArrowRight size={16} />
            </button>
          </section>
        </div>
      )}
    </div>
  );
}
