"use client";
import { useCallback, useEffect, useState } from "react";
import { useClient, useCurrentUser } from "sanity";
import { actionLabels, type Opportunity, type Proposal } from "../lib/model";
import { fixtures, currencyUpdate } from "../lib/fixtures";
import { evaluate, approvalError } from "../lib/evaluate";
import { apiVersion, query } from "../lib/sanity";
import { appendEvidence, approveProposal, saveProposal } from "./workflow";

type StoredProposal = Proposal & { _rev: string };
export function ReviewDesk() {
  const client = useClient({ apiVersion });
  const user = useCurrentUser();
  const [items, setItems] = useState<Opportunity[]>([]),
    [proposals, setProposals] = useState<StoredProposal[]>([]);
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [loaded, setLoaded] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const reload = useCallback(async () => {
    const [records, reviews] = await Promise.all([
      client.fetch<Opportunity[]>(query),
      client.fetch<StoredProposal[]>(
        '*[_type == "reviewProposal" && !(_id in path("drafts.**")) && !(_id in path("versions.**"))] | order(proposedAt desc)',
      ),
    ]);
    setItems(records);
    setProposals(reviews);
    setNow(new Date());
    setLoaded(true);
  }, [client]);
  useEffect(() => {
    reload().catch(() =>
      setMessage(
        "Unable to read the dataset. Check your Sanity permissions and connection.",
      ),
    );
  }, [reload]);
  async function run(action: () => Promise<unknown>, success: string) {
    if (busy) return;
    setBusy(true);
    setMessage("");
    try {
      await action();
      await reload();
      setMessage(success);
    } catch (e) {
      setMessage(
        e instanceof Error
          ? e.message
          : "The write did not complete. Reload before retrying.",
      );
    } finally {
      setBusy(false);
    }
  }
  async function seed() {
    let tx = client.transaction();
    for (const fixture of fixtures) {
      const { _rev, ...doc } = fixture;
      tx = tx.createIfNotExists({
        ...doc,
        evidence: doc.evidence.map((e) => ({ _type: "evidence", ...e })),
      });
    }
    return tx.commit({ visibility: "sync" });
  }
  return (
    <div className="editor-desk">
      <span className="eyebrow">AUTHENTICATED SANITY WORKSPACE</span>
      <h1>Still Open · Review desk</h1>
      <p>
        Shared synthetic data. These buttons write to the public Sanity dataset.
        No client information, contact details, authentication identifiers, or
        payment records belong here.
      </p>
      <div className="editor-toolbar">
        <button
          disabled={busy}
          onClick={() => run(reload, "Latest source revisions loaded.")}
        >
          Refresh shared data
        </button>
        {loaded && !items.length && (
          <button
            disabled={busy || !user}
            onClick={() =>
              run(
                seed,
                "Six synthetic examples saved to Sanity. Existing documents were not overwritten.",
              )
            }
          >
            Load six synthetic examples
          </button>
        )}
        <a href="/" target="_blank" rel="noreferrer">
          Open public board ↗
        </a>
      </div>
      <div className="editor-alert">
        The public board is a rehearsal. This workspace saves real review
        records using your signed-in Sanity permissions. It does not send
        applications or accept any agreement.
      </div>
      {message && (
        <div className="editor-log" role="status">
          {message}
        </div>
      )}
      {!loaded && <p>Loading shared records…</p>}
      {items.map((item) => {
        const assessment = evaluate(item, now);
        const pending = proposals.filter(
          (p) => p.opportunity._ref === item._id && p.status === "pending",
        );
        const done = proposals.filter(
          (p) => p.opportunity._ref === item._id && p.status === "approved",
        );
        return (
          <article className="editor-row" key={item._id}>
            <h2>{item.title}</h2>
            <p>
              {assessment.budget} · {item.buyer} · {assessment.state}
            </p>
            <div className="editor-reasons">
              {assessment.reasons.map((r) => (
                <div key={r.code}>
                  {r.label}: {r.detail}
                </div>
              ))}
            </div>
            <button
              disabled={busy || !user}
              onClick={() =>
                run(
                  () =>
                    saveProposal(
                      client,
                      item,
                      new Date(),
                      "review-" + crypto.randomUUID(),
                    ),
                  "Proposal saved. A separate review is still required.",
                )
              }
            >
              Save proposed next step
            </button>
            {item._id === "demo-currency" &&
              !item.evidence.some((e) =>
                e._key.startsWith("currency-followup"),
              ) && (
                <button
                  disabled={busy || !user}
                  onClick={() =>
                    run(
                      () =>
                        appendEvidence(
                          client,
                          item,
                          currencyUpdate(new Date().toISOString()),
                        ),
                      "New synthetic source saved. Older proposals cannot be approved.",
                    )
                  }
                >
                  Add synthetic SEK clarification
                </button>
              )}
            {pending.map((p) => {
              const blocked = approvalError(item, p, now);
              return (
                <div className="editor-pending" key={p._id}>
                  <strong>{actionLabels[p.action]}</strong>
                  <p>
                    Pending · based on <code>{p.basedOnRevision}</code>
                  </p>
                  {blocked && <div className="editor-reasons">{blocked}</div>}
                  <button
                    disabled={busy || !!blocked || !user}
                    onClick={() =>
                      run(
                        () => approveProposal(client, item, p, new Date()),
                        "Review saved atomically. No message or contract was created.",
                      )
                    }
                  >
                    Approve this review
                  </button>
                </div>
              );
            })}
            {done.map((p) => (
              <div className="editor-log" key={p._id}>
                Recorded: {actionLabels[p.action]} · {p.reviewedAt}. Historical
                decision; re-check current evidence before any further action.
              </div>
            ))}
          </article>
        );
      })}
    </div>
  );
}
