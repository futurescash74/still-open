import { defineArrayMember, defineField, defineType } from "sanity";
import { claims, claimLabels } from "../lib/model";

const evidence = defineType({
  name: "evidence",
  title: "Source observation",
  type: "object",
  fields: [
    defineField({
      name: "claim",
      type: "string",
      options: {
        list: claims.map((value) => ({ value, title: claimLabels[value] })),
      },
      validation: (r) => r.required(),
    }),
    defineField({
      name: "value",
      type: "string",
      description:
        "Structured value used by the evaluator: open/closed, amount, ISO currency, cash/credits, verified, confirmed, defined, allowed, or unknown.",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "amount",
      type: "number",
      description: "Only for the budget fact. This is not income.",
      hidden: ({ parent }) => parent?.claim !== "budget",
      validation: (r) => r.positive(),
    }),
    defineField({
      name: "sourceType",
      type: "string",
      options: {
        list: [
          { title: "Direct buyer", value: "buyer" },
          { title: "Official source", value: "official" },
          { title: "Third-party / cached", value: "thirdParty" },
        ],
      },
      validation: (r) => r.required(),
    }),
    defineField({
      name: "sourceLabel",
      type: "string",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "sourceUrl",
      type: "url",
      validation: (r) => r.required().uri({ scheme: ["https", "http"] }),
    }),
    defineField({
      name: "excerpt",
      type: "text",
      rows: 3,
      validation: (r) => r.required().max(1000),
    }),
    defineField({
      name: "publishedAt",
      type: "datetime",
      description: "When the source actually made the statement.",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "capturedAt",
      type: "datetime",
      description: "When we read the source. This does not reset freshness.",
      validation: (r) => r.required(),
    }),
  ],
  preview: { select: { title: "sourceLabel", subtitle: "claim" } },
});

const opportunity = defineType({
  name: "opportunity",
  type: "document",
  title: "Opportunity",
  fields: [
    defineField({
      name: "title",
      type: "string",
      validation: (r) => r.required().max(100),
    }),
    defineField({
      name: "buyer",
      type: "string",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "category",
      type: "string",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "summary",
      type: "text",
      rows: 3,
      validation: (r) => r.required(),
    }),
    defineField({
      name: "effort",
      type: "string",
      description: "A rough estimate, never a delivery commitment.",
    }),
    defineField({
      name: "synthetic",
      type: "boolean",
      initialValue: true,
      readOnly: true,
      validation: (r) =>
        r
          .required()
          .custom(
            (value) =>
              value === true ||
              "Only synthetic examples belong in this public demo.",
          ),
    }),
    defineField({
      name: "evidence",
      type: "array",
      of: [defineArrayMember({ type: "evidence" })],
      validation: (r) => r.required().min(1),
    }),
    defineField({ name: "lastReviewedAt", type: "datetime", readOnly: true }),
  ],
  preview: { select: { title: "title", subtitle: "buyer" } },
});

const proposal = defineType({
  name: "reviewProposal",
  type: "document",
  title: "Review proposal",
  readOnly: true,
  fields: [
    defineField({
      name: "opportunity",
      type: "reference",
      to: [{ type: "opportunity" }],
      validation: (r) => r.required(),
    }),
    defineField({
      name: "basedOnRevision",
      type: "string",
      validation: (r) => r.required(),
    }),
    defineField({
      name: "action",
      type: "string",
      options: { list: ["clarify", "prepare", "archive"] },
    }),
    defineField({
      name: "reasonCodes",
      type: "array",
      of: [defineArrayMember({ type: "string" })],
    }),
    defineField({ name: "budgetSnapshot", type: "string" }),
    defineField({
      name: "reasons",
      type: "array",
      of: [
        defineArrayMember({
          name: "reasonSnapshot",
          type: "object",
          fields: [
            defineField({ name: "code", type: "string" }),
            defineField({ name: "claim", type: "string" }),
            defineField({ name: "label", type: "string" }),
            defineField({ name: "detail", type: "text" }),
          ],
        }),
      ],
    }),
    defineField({ name: "proposedAt", type: "datetime" }),
    defineField({ name: "validUntil", type: "datetime" }),
    defineField({
      name: "status",
      type: "string",
      options: { list: ["pending", "approved", "rejected"] },
    }),
    defineField({ name: "reviewedAt", type: "datetime" }),
    defineField({
      name: "reviewerId",
      type: "string",
      description:
        "Pseudonymous demo reviewer label; never a personal email or authentication identifier.",
    }),
  ],
  preview: { select: { title: "action", subtitle: "status" } },
});
export const schemaTypes = [evidence, opportunity, proposal];
