import type { SanityClient } from "@sanity/client";
import { approvalError, propose } from "../lib/evaluate";
import type { Evidence, Opportunity, Proposal } from "../lib/model";

export async function saveProposal(
  client: SanityClient,
  opportunity: Opportunity,
  now: Date,
  id: string,
) {
  // Saving a suggestion does not approve it. A concurrent source edit is checked at approval.
  const proposal = propose(opportunity, now, id);
  return client.create({
    ...proposal,
    reasons: proposal.reasons.map((reason, index) => ({
      _key: "reason-" + index,
      _type: "reasonSnapshot",
      ...reason,
    })),
  });
}
export async function approveProposal(
  client: SanityClient,
  opportunity: Opportunity,
  proposal: Proposal & { _rev: string },
  now: Date,
) {
  const error = approvalError(opportunity, proposal, now);
  if (error) throw new Error(error);
  // Both checks are in the same atomic transaction: no stale-source approval or double review.
  return client
    .transaction()
    .patch(opportunity._id, (p) =>
      p
        .ifRevisionId(opportunity._rev)
        .set({ lastReviewedAt: now.toISOString() }),
    )
    .patch(proposal._id, (p) =>
      p.ifRevisionId(proposal._rev).set({
        status: "approved",
        reviewedAt: now.toISOString(),
        reviewerId: "demo-editor",
      }),
    )
    .commit({ visibility: "sync" });
}
export async function appendEvidence(
  client: SanityClient,
  opportunity: Opportunity,
  evidence: Evidence,
) {
  if (opportunity.evidence.some((e) => e._key === evidence._key))
    throw new Error("This source observation already exists.");
  return client
    .patch(opportunity._id)
    .ifRevisionId(opportunity._rev)
    .setIfMissing({ evidence: [] })
    .append("evidence", [{ _type: "evidence", ...evidence }])
    .commit({ visibility: "sync" });
}
