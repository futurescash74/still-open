import test from "node:test";
import assert from "node:assert/strict";
import type { SanityClient } from "@sanity/client";
import { fixtures, DEMO_NOW } from "../src/lib/fixtures";
import { propose } from "../src/lib/evaluate";
import { approveProposal } from "../src/sanity/workflow";

test("approval atomically checks both source and proposal revisions", async () => {
  const op = structuredClone(fixtures[1]),
    now = new Date(DEMO_NOW),
    proposal = { ...propose(op, now, "test-review"), _rev: "review-revision" };
  const patches: { id: string; rev?: string; fields?: unknown }[] = [];
  let commits = 0;
  const tx = {
    patch(id: string, fn: (patch: unknown) => unknown) {
      const captured: { id: string; rev?: string; fields?: unknown } = { id };
      const patch = {
        ifRevisionId(rev: string) {
          captured.rev = rev;
          return patch;
        },
        set(fields: unknown) {
          captured.fields = fields;
          return patch;
        },
      };
      fn(patch);
      patches.push(captured);
      return tx;
    },
    async commit() {
      commits++;
      return {};
    },
  };
  const client = { transaction: () => tx } as unknown as SanityClient;
  await approveProposal(client, op, proposal, now);
  assert.equal(commits, 1);
  assert.deepEqual(
    patches.map((p) => [p.id, p.rev]),
    [
      [op._id, op._rev],
      [proposal._id, proposal._rev],
    ],
  );
  assert.deepEqual(patches[1].fields, {
    status: "approved",
    reviewedAt: DEMO_NOW,
    reviewerId: "demo-editor",
  });
});
test("a stale review is rejected before any transaction is opened", async () => {
  const op = structuredClone(fixtures[1]),
    now = new Date(DEMO_NOW),
    proposal = { ...propose(op, now, "test-review"), _rev: "review-revision" };
  op._rev = "new";
  let writes = 0;
  const client = {
    transaction() {
      writes++;
      throw new Error("Unexpected write");
    },
  } as unknown as SanityClient;
  await assert.rejects(
    approveProposal(client, op, proposal, now),
    /evidence changed/,
  );
  assert.equal(writes, 0);
});
test("an atomic database revision conflict is surfaced and never retried blindly", async () => {
  const op = structuredClone(fixtures[1]),
    now = new Date(DEMO_NOW),
    proposal = { ...propose(op, now, "test-review"), _rev: "review-revision" };
  let commits = 0;
  const tx = {
    patch() {
      return tx;
    },
    async commit() {
      commits++;
      throw new Error("409 revision mismatch");
    },
  };
  await assert.rejects(
    approveProposal(
      { transaction: () => tx } as unknown as SanityClient,
      op,
      proposal,
      now,
    ),
    /409/,
  );
  assert.equal(commits, 1);
});
