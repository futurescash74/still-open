import test from "node:test";
import assert from "node:assert/strict";
import { evaluate, propose, approvalError } from "../src/lib/evaluate";
import { fixtures, DEMO_NOW, currencyUpdate } from "../src/lib/fixtures";
import { safeSourceUrl, type Opportunity } from "../src/lib/model";
const now = new Date(DEMO_NOW);
const record = (id: string) =>
  structuredClone(fixtures.find((x) => x._id === "demo-" + id)!);

test("a missing currency is never inferred from a large budget", () => {
  const e = evaluate(record("currency"), now);
  assert.equal(e.state, "review");
  assert.equal(e.action, "clarify");
  assert.match(e.budget, /currency unknown/);
  assert.ok(e.reasons.some((r) => r.code === "currency-unknown"));
});
test("a complete fresh brief can justify a proposal, never payment or acceptance", () => {
  const e = evaluate(record("ready"), now);
  assert.equal(e.action, "prepare");
  assert.deepEqual(e.reasons, []);
  assert.equal(e.budget, "1,200 USD");
});
test("a fresh cached listing cannot reopen a buyer-closed job", () => {
  const e = evaluate(record("closed"), now);
  assert.equal(e.state, "closed");
  assert.equal(e.action, "archive");
  assert.equal(e.selected.availability?.value, "closed");
});
test("account credits do not qualify as cash compensation", () => {
  const e = evaluate(record("credits"), now);
  assert.equal(e.state, "review");
  assert.ok(e.reasons.some((r) => r.code === "not-cash"));
});
test("capturing an old post today does not refresh its confirmation", () => {
  const e = evaluate(record("stale"), now);
  assert.equal(e.action, "clarify");
  assert.equal(e.reasons.filter((r) => r.code.startsWith("stale:")).length, 8);
});
test("a known payout provider without participant eligibility is unresolved", () => {
  const e = evaluate(record("payment"), now);
  assert.ok(e.reasons.some((r) => r.code === "payment-unconfirmed"));
  assert.equal(e.action, "clarify");
});
test("a buyer can explicitly reopen a job after closing it", () => {
  const op = record("closed");
  op.evidence.push({
    ...op.evidence[0],
    _key: "reopen",
    value: "open",
    publishedAt: "2026-09-27T11:00:00Z",
    capturedAt: DEMO_NOW,
  });
  assert.equal(evaluate(op, now).state, "ready");
});
test("equally authoritative simultaneous contradictions remain unresolved", () => {
  const op = record("ready");
  op.evidence.push({ ...op.evidence[0], _key: "conflict", value: "closed" });
  const e = evaluate(op, now);
  assert.equal(e.state, "review");
  assert.equal(e.selected.availability, undefined);
  assert.ok(e.reasons.some((r) => r.code === "conflict:availability"));
});
test("future, invalid and reversed source dates cannot supply usable evidence", () => {
  for (const publishedAt of ["bad-date", "2026-09-28T12:00:00Z"]) {
    const op = record("ready");
    op.evidence[0].publishedAt = publishedAt;
    const e = evaluate(op, now);
    assert.equal(e.state, "review");
    assert.ok(e.reasons.some((r) => r.code === "invalid-date:availability"));
  }
});
test("secondary evidence alone cannot verify a buyer", () => {
  const op = record("ready");
  op.evidence = op.evidence.map((e) => ({ ...e, sourceType: "thirdParty" }));
  assert.equal(evaluate(op, now).state, "review");
});
test("invalid numeric budgets never become ready", () => {
  for (const amount of [0, -100, Number.NaN, Number.POSITIVE_INFINITY]) {
    const op = record("ready");
    op.evidence.find((e) => e.claim === "budget")!.amount = amount;
    assert.equal(evaluate(op, now).state, "review");
  }
});
test("a changed source revision invalidates a pending proposal", () => {
  const op = record("currency");
  const p = propose(op, now, "proposal");
  op.evidence.push(currencyUpdate(DEMO_NOW));
  op._rev = "changed";
  assert.match(approvalError(op, p, now)!, /evidence changed/i);
  const fresh = propose(op, now, "fresh");
  assert.equal(fresh.action, "prepare");
  assert.equal(approvalError(op, fresh, now), undefined);
});
test("review applies only to its referenced opportunity and only once", () => {
  const op = record("ready");
  const p = propose(op, now, "proposal");
  assert.match(
    approvalError(record("currency"), p, now)!,
    /another opportunity/,
  );
  p.status = "approved";
  assert.match(approvalError(op, p, now)!, /already been reviewed/);
});
test("proposals expire even if the content revision stays unchanged", () => {
  const op = record("ready");
  const p = propose(op, now, "proposal");
  assert.match(
    approvalError(op, p, new Date("2026-09-28T12:00:00Z"))!,
    /expired/,
  );
});
test("a proposal cannot survive its earliest evidence expiration", () => {
  const op = record("ready");
  op.evidence[0].publishedAt = "2026-09-13T13:00:00Z";
  const p = propose(op, now, "proposal");
  assert.equal(p.validUntil, "2026-09-27T13:00:00.000Z");
  assert.match(
    approvalError(op, p, new Date("2026-09-27T13:00:00Z"))!,
    /expired/,
  );
});
test("changing the proposed action is rejected even without a source edit", () => {
  const op = record("currency");
  const p = propose(op, now, "proposal");
  p.action = "prepare";
  assert.match(approvalError(op, p, now)!, /assessment changed/);
});
test("source links cannot execute scripts or embed credentials", () => {
  assert.equal(safeSourceUrl("javascript:alert(1)"), undefined);
  assert.equal(safeSourceUrl("data:text/html,no"), undefined);
  assert.equal(safeSourceUrl("https://secret:password@example.com"), undefined);
  assert.equal(
    safeSourceUrl("https://example.com/source"),
    "https://example.com/source",
  );
});
test("demo records are explicitly synthetic and contain no email destinations", () => {
  for (const op of fixtures) {
    assert.equal(op.synthetic, true);
    for (const e of op.evidence)
      assert.equal(new URL(e.sourceUrl).hostname, "example.com");
  }
  assert.doesNotMatch(JSON.stringify(fixtures), /@|bjrn|norman|paypal\.me/i);
});
test("equal instants with different timezone strings still conflict", () => {
  const op = record("ready");
  op.evidence.push({
    ...op.evidence[0],
    _key: "same-instant",
    value: "closed",
    publishedAt: "2026-09-26T12:00:00+02:00",
  });
  assert.ok(
    evaluate(op, now).reasons.some((r) => r.code === "conflict:availability"),
  );
});
test("a proposal retains its original reasons after the source is clarified", () => {
  const op = record("currency");
  const p = propose(op, now, "proposal");
  op.evidence.push(currencyUpdate(DEMO_NOW));
  op._rev = "new";
  assert.equal(evaluate(op, now).reasons.length, 0);
  assert.equal(p.reasons[0].code, "currency-unknown");
  assert.match(p.budgetSnapshot, /currency unknown/);
});
test("a number labeled as something other than budget is not accepted", () => {
  const op = record("ready");
  op.evidence.find((e) => e.claim === "budget")!.value = "unknown";
  assert.equal(evaluate(op, now).state, "review");
});
test("credit-only rewards are clearly labeled in the budget display", () => {
  assert.equal(
    evaluate(record("credits"), now).budget,
    "500 credits · no cash",
  );
});
